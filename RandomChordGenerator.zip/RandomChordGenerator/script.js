$(document).ready(function() {
  $('#text').click(function() {
//Empty array for chord progression to be pushed into
var progression = [];
var key;
var randomNumber = Math.round(Math.random());
var majorMinor;

/* Pushes 4 random chords into the empty array to create 4 chord progression */
function addChord1(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  var num = Math.floor(Math.random() * (max - min + 1)) + min;
      switch(num) {
        case 1:
          progression.push(" I chord");
          break;
        case 2:
          progression.push(" ii chord");
          break;
        case 3:
          progression.push(" iii chord");
          break;
        case 4:
          progression.push(" IV chord");
          break;
        case 5:
          progression.push(" V chord");
          break;
        case 6:
          progression.push(" vi chord");
          break;
        case 7:
          progression.push(" diminished vii chord");
          break;
      }
}

/* Pushes 4 random chords into the empty array to create 4 chord progression */
function addChord2(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  var num = Math.floor(Math.random() * (max - min + 1)) + min;
      switch(num) {
        case 1:
          progression.push(" i chord");
          break;
        case 2:
          progression.push(" diminished ii chord");
          break;
        case 3:
          progression.push(" III chord");
          break;
        case 4:
          progression.push(" iv chord");
          break;
        case 5:
          progression.push(" V chord");
          break;
        case 6:
          progression.push(" VI chord");
          break;
        case 7:
          progression.push(" VII or diminished vii chord");
          break;
      }
}

//Randomly picks a key for progression
function pickKey(min, max) {
	min = Math.ceil(min);
  max = Math.floor(max);
  var num = Math.floor(Math.random() * (max - min +1)) + min;
      switch(num) {
        case 1:
          key = " A";
          break;
        case 2:
          key = " A#/Bb";
          break;
        case 3:
          key = " B";
          break;
        case 4:
          key = " C";
          break;
        case 5:
          key = " C#/Db";
          break;
        case 6:
          key = " D";
          break;
        case 7:
          key = " D#/Eb";
          break;
        case 8:
          key = " E";
          break;
        case 9:
          key = " F";
          break;
        case 10:
          key = " F#/Gb";
          break;
        case 11:
          key = " G";
          break;
        case 12:
          key = " G#/Ab";
          break;
      }
}

//calls function 4 times to produce 4 chord progression
while (progression.length < 4) {
	if (randomNumber === 0) {
 		addChord1(1,7);
    majorMinor = " Major";
  }
  else if (randomNumber === 1) {
  	addChord2(1,7);
  	majorMinor = " Minor";
  }
}

pickKey(1,12);
//pop up that displays chord progression
$('#result').append("<li>Here is your random chord progression:" + progression + ". Play this progression in the key of" + key + majorMinor + ".</li>");

  });
});